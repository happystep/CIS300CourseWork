﻿namespace Ksu.Cis300.Nim
{
    partial class UserInterface
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.uxBoard2Limit3 = new System.Windows.Forms.NumericUpDown();
            this.uxBoard2Limit2 = new System.Windows.Forms.NumericUpDown();
            this.uxBoard2Limit1 = new System.Windows.Forms.NumericUpDown();
            this.uxBoard2Value3 = new System.Windows.Forms.NumericUpDown();
            this.uxBoard2Value2 = new System.Windows.Forms.NumericUpDown();
            this.uxBoard2Value1 = new System.Windows.Forms.NumericUpDown();
            this.uxBoard1Limit3 = new System.Windows.Forms.NumericUpDown();
            this.uxBoard1Limit2 = new System.Windows.Forms.NumericUpDown();
            this.uxBoard1Limit1 = new System.Windows.Forms.NumericUpDown();
            this.uxBoard1Value3 = new System.Windows.Forms.NumericUpDown();
            this.uxBoard1Value2 = new System.Windows.Forms.NumericUpDown();
            this.uxBoard1Value1 = new System.Windows.Forms.NumericUpDown();
            this.uxAreDoubleEqual = new System.Windows.Forms.TextBox();
            this.uxDoubleEqualsLabel = new System.Windows.Forms.Label();
            this.uxAreEqual = new System.Windows.Forms.TextBox();
            this.uxEqualsLabel = new System.Windows.Forms.Label();
            this.uxCompare = new System.Windows.Forms.Button();
            this.uxLimit2Label = new System.Windows.Forms.Label();
            this.uxValues2Label = new System.Windows.Forms.Label();
            this.uxBoard2Label = new System.Windows.Forms.Label();
            this.uxLimitsLabel1 = new System.Windows.Forms.Label();
            this.uxValueLabel1 = new System.Windows.Forms.Label();
            this.uxBoard1Label = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.uxBoard2Limit3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uxBoard2Limit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uxBoard2Limit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uxBoard2Value3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uxBoard2Value2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uxBoard2Value1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uxBoard1Limit3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uxBoard1Limit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uxBoard1Limit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uxBoard1Value3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uxBoard1Value2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uxBoard1Value1)).BeginInit();
            this.SuspendLayout();
            // 
            // uxBoard2Limit3
            // 
            this.uxBoard2Limit3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxBoard2Limit3.Location = new System.Drawing.Point(190, 186);
            this.uxBoard2Limit3.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.uxBoard2Limit3.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.uxBoard2Limit3.Name = "uxBoard2Limit3";
            this.uxBoard2Limit3.Size = new System.Drawing.Size(43, 26);
            this.uxBoard2Limit3.TabIndex = 90;
            this.uxBoard2Limit3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.uxBoard2Limit3.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // uxBoard2Limit2
            // 
            this.uxBoard2Limit2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxBoard2Limit2.Location = new System.Drawing.Point(141, 186);
            this.uxBoard2Limit2.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.uxBoard2Limit2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.uxBoard2Limit2.Name = "uxBoard2Limit2";
            this.uxBoard2Limit2.Size = new System.Drawing.Size(43, 26);
            this.uxBoard2Limit2.TabIndex = 89;
            this.uxBoard2Limit2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.uxBoard2Limit2.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // uxBoard2Limit1
            // 
            this.uxBoard2Limit1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxBoard2Limit1.Location = new System.Drawing.Point(92, 186);
            this.uxBoard2Limit1.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.uxBoard2Limit1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.uxBoard2Limit1.Name = "uxBoard2Limit1";
            this.uxBoard2Limit1.Size = new System.Drawing.Size(43, 26);
            this.uxBoard2Limit1.TabIndex = 88;
            this.uxBoard2Limit1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.uxBoard2Limit1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // uxBoard2Value3
            // 
            this.uxBoard2Value3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxBoard2Value3.Location = new System.Drawing.Point(190, 154);
            this.uxBoard2Value3.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.uxBoard2Value3.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.uxBoard2Value3.Name = "uxBoard2Value3";
            this.uxBoard2Value3.Size = new System.Drawing.Size(43, 26);
            this.uxBoard2Value3.TabIndex = 87;
            this.uxBoard2Value3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.uxBoard2Value3.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // uxBoard2Value2
            // 
            this.uxBoard2Value2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxBoard2Value2.Location = new System.Drawing.Point(141, 154);
            this.uxBoard2Value2.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.uxBoard2Value2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.uxBoard2Value2.Name = "uxBoard2Value2";
            this.uxBoard2Value2.Size = new System.Drawing.Size(43, 26);
            this.uxBoard2Value2.TabIndex = 86;
            this.uxBoard2Value2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.uxBoard2Value2.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // uxBoard2Value1
            // 
            this.uxBoard2Value1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxBoard2Value1.Location = new System.Drawing.Point(92, 154);
            this.uxBoard2Value1.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.uxBoard2Value1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.uxBoard2Value1.Name = "uxBoard2Value1";
            this.uxBoard2Value1.Size = new System.Drawing.Size(43, 26);
            this.uxBoard2Value1.TabIndex = 85;
            this.uxBoard2Value1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.uxBoard2Value1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // uxBoard1Limit3
            // 
            this.uxBoard1Limit3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxBoard1Limit3.Location = new System.Drawing.Point(190, 75);
            this.uxBoard1Limit3.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.uxBoard1Limit3.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.uxBoard1Limit3.Name = "uxBoard1Limit3";
            this.uxBoard1Limit3.Size = new System.Drawing.Size(43, 26);
            this.uxBoard1Limit3.TabIndex = 84;
            this.uxBoard1Limit3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.uxBoard1Limit3.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // uxBoard1Limit2
            // 
            this.uxBoard1Limit2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxBoard1Limit2.Location = new System.Drawing.Point(141, 75);
            this.uxBoard1Limit2.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.uxBoard1Limit2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.uxBoard1Limit2.Name = "uxBoard1Limit2";
            this.uxBoard1Limit2.Size = new System.Drawing.Size(43, 26);
            this.uxBoard1Limit2.TabIndex = 83;
            this.uxBoard1Limit2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.uxBoard1Limit2.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // uxBoard1Limit1
            // 
            this.uxBoard1Limit1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxBoard1Limit1.Location = new System.Drawing.Point(92, 75);
            this.uxBoard1Limit1.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.uxBoard1Limit1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.uxBoard1Limit1.Name = "uxBoard1Limit1";
            this.uxBoard1Limit1.Size = new System.Drawing.Size(43, 26);
            this.uxBoard1Limit1.TabIndex = 82;
            this.uxBoard1Limit1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.uxBoard1Limit1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // uxBoard1Value3
            // 
            this.uxBoard1Value3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxBoard1Value3.Location = new System.Drawing.Point(190, 43);
            this.uxBoard1Value3.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.uxBoard1Value3.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.uxBoard1Value3.Name = "uxBoard1Value3";
            this.uxBoard1Value3.Size = new System.Drawing.Size(43, 26);
            this.uxBoard1Value3.TabIndex = 81;
            this.uxBoard1Value3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.uxBoard1Value3.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // uxBoard1Value2
            // 
            this.uxBoard1Value2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxBoard1Value2.Location = new System.Drawing.Point(141, 43);
            this.uxBoard1Value2.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.uxBoard1Value2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.uxBoard1Value2.Name = "uxBoard1Value2";
            this.uxBoard1Value2.Size = new System.Drawing.Size(43, 26);
            this.uxBoard1Value2.TabIndex = 80;
            this.uxBoard1Value2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.uxBoard1Value2.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // uxBoard1Value1
            // 
            this.uxBoard1Value1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxBoard1Value1.Location = new System.Drawing.Point(92, 43);
            this.uxBoard1Value1.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.uxBoard1Value1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.uxBoard1Value1.Name = "uxBoard1Value1";
            this.uxBoard1Value1.Size = new System.Drawing.Size(43, 26);
            this.uxBoard1Value1.TabIndex = 79;
            this.uxBoard1Value1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.uxBoard1Value1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // uxAreDoubleEqual
            // 
            this.uxAreDoubleEqual.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxAreDoubleEqual.Location = new System.Drawing.Point(103, 345);
            this.uxAreDoubleEqual.Name = "uxAreDoubleEqual";
            this.uxAreDoubleEqual.ReadOnly = true;
            this.uxAreDoubleEqual.Size = new System.Drawing.Size(130, 29);
            this.uxAreDoubleEqual.TabIndex = 78;
            this.uxAreDoubleEqual.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // uxDoubleEqualsLabel
            // 
            this.uxDoubleEqualsLabel.AutoSize = true;
            this.uxDoubleEqualsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxDoubleEqualsLabel.Location = new System.Drawing.Point(24, 348);
            this.uxDoubleEqualsLabel.Name = "uxDoubleEqualsLabel";
            this.uxDoubleEqualsLabel.Size = new System.Drawing.Size(72, 24);
            this.uxDoubleEqualsLabel.TabIndex = 77;
            this.uxDoubleEqualsLabel.Text = "Are ==:";
            // 
            // uxAreEqual
            // 
            this.uxAreEqual.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxAreEqual.Location = new System.Drawing.Point(103, 310);
            this.uxAreEqual.Name = "uxAreEqual";
            this.uxAreEqual.ReadOnly = true;
            this.uxAreEqual.Size = new System.Drawing.Size(130, 29);
            this.uxAreEqual.TabIndex = 76;
            this.uxAreEqual.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // uxEqualsLabel
            // 
            this.uxEqualsLabel.AutoSize = true;
            this.uxEqualsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxEqualsLabel.Location = new System.Drawing.Point(24, 313);
            this.uxEqualsLabel.Name = "uxEqualsLabel";
            this.uxEqualsLabel.Size = new System.Drawing.Size(73, 24);
            this.uxEqualsLabel.TabIndex = 75;
            this.uxEqualsLabel.Text = "Equals:";
            // 
            // uxCompare
            // 
            this.uxCompare.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxCompare.Location = new System.Drawing.Point(28, 260);
            this.uxCompare.Name = "uxCompare";
            this.uxCompare.Size = new System.Drawing.Size(205, 44);
            this.uxCompare.TabIndex = 74;
            this.uxCompare.Text = "Compare Boards";
            this.uxCompare.UseVisualStyleBackColor = true;
            this.uxCompare.Click += new System.EventHandler(this.uxCompare_Click);
            // 
            // uxLimit2Label
            // 
            this.uxLimit2Label.AutoSize = true;
            this.uxLimit2Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxLimit2Label.Location = new System.Drawing.Point(24, 188);
            this.uxLimit2Label.Name = "uxLimit2Label";
            this.uxLimit2Label.Size = new System.Drawing.Size(54, 20);
            this.uxLimit2Label.TabIndex = 73;
            this.uxLimit2Label.Text = "Limits:";
            // 
            // uxValues2Label
            // 
            this.uxValues2Label.AutoSize = true;
            this.uxValues2Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxValues2Label.Location = new System.Drawing.Point(24, 156);
            this.uxValues2Label.Name = "uxValues2Label";
            this.uxValues2Label.Size = new System.Drawing.Size(62, 20);
            this.uxValues2Label.TabIndex = 72;
            this.uxValues2Label.Text = "Values:";
            // 
            // uxBoard2Label
            // 
            this.uxBoard2Label.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.uxBoard2Label.AutoSize = true;
            this.uxBoard2Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxBoard2Label.Location = new System.Drawing.Point(96, 127);
            this.uxBoard2Label.Name = "uxBoard2Label";
            this.uxBoard2Label.Size = new System.Drawing.Size(75, 24);
            this.uxBoard2Label.TabIndex = 71;
            this.uxBoard2Label.Text = "Board 2";
            // 
            // uxLimitsLabel1
            // 
            this.uxLimitsLabel1.AutoSize = true;
            this.uxLimitsLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxLimitsLabel1.Location = new System.Drawing.Point(24, 77);
            this.uxLimitsLabel1.Name = "uxLimitsLabel1";
            this.uxLimitsLabel1.Size = new System.Drawing.Size(54, 20);
            this.uxLimitsLabel1.TabIndex = 70;
            this.uxLimitsLabel1.Text = "Limits:";
            // 
            // uxValueLabel1
            // 
            this.uxValueLabel1.AutoSize = true;
            this.uxValueLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxValueLabel1.Location = new System.Drawing.Point(24, 45);
            this.uxValueLabel1.Name = "uxValueLabel1";
            this.uxValueLabel1.Size = new System.Drawing.Size(62, 20);
            this.uxValueLabel1.TabIndex = 69;
            this.uxValueLabel1.Text = "Values:";
            // 
            // uxBoard1Label
            // 
            this.uxBoard1Label.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.uxBoard1Label.AutoSize = true;
            this.uxBoard1Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxBoard1Label.Location = new System.Drawing.Point(96, 16);
            this.uxBoard1Label.Name = "uxBoard1Label";
            this.uxBoard1Label.Size = new System.Drawing.Size(75, 24);
            this.uxBoard1Label.TabIndex = 68;
            this.uxBoard1Label.Text = "Board 1";
            // 
            // UserInterface
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(256, 390);
            this.Controls.Add(this.uxBoard2Limit3);
            this.Controls.Add(this.uxBoard2Limit2);
            this.Controls.Add(this.uxBoard2Limit1);
            this.Controls.Add(this.uxBoard2Value3);
            this.Controls.Add(this.uxBoard2Value2);
            this.Controls.Add(this.uxBoard2Value1);
            this.Controls.Add(this.uxBoard1Limit3);
            this.Controls.Add(this.uxBoard1Limit2);
            this.Controls.Add(this.uxBoard1Limit1);
            this.Controls.Add(this.uxBoard1Value3);
            this.Controls.Add(this.uxBoard1Value2);
            this.Controls.Add(this.uxBoard1Value1);
            this.Controls.Add(this.uxAreDoubleEqual);
            this.Controls.Add(this.uxDoubleEqualsLabel);
            this.Controls.Add(this.uxAreEqual);
            this.Controls.Add(this.uxEqualsLabel);
            this.Controls.Add(this.uxCompare);
            this.Controls.Add(this.uxLimit2Label);
            this.Controls.Add(this.uxValues2Label);
            this.Controls.Add(this.uxBoard2Label);
            this.Controls.Add(this.uxLimitsLabel1);
            this.Controls.Add(this.uxValueLabel1);
            this.Controls.Add(this.uxBoard1Label);
            this.Name = "UserInterface";
            this.Text = "Nim Board Comparer";
            ((System.ComponentModel.ISupportInitialize)(this.uxBoard2Limit3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uxBoard2Limit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uxBoard2Limit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uxBoard2Value3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uxBoard2Value2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uxBoard2Value1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uxBoard1Limit3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uxBoard1Limit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uxBoard1Limit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uxBoard1Value3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uxBoard1Value2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uxBoard1Value1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown uxBoard2Limit3;
        private System.Windows.Forms.NumericUpDown uxBoard2Limit2;
        private System.Windows.Forms.NumericUpDown uxBoard2Limit1;
        private System.Windows.Forms.NumericUpDown uxBoard2Value3;
        private System.Windows.Forms.NumericUpDown uxBoard2Value2;
        private System.Windows.Forms.NumericUpDown uxBoard2Value1;
        private System.Windows.Forms.NumericUpDown uxBoard1Limit3;
        private System.Windows.Forms.NumericUpDown uxBoard1Limit2;
        private System.Windows.Forms.NumericUpDown uxBoard1Limit1;
        private System.Windows.Forms.NumericUpDown uxBoard1Value3;
        private System.Windows.Forms.NumericUpDown uxBoard1Value2;
        private System.Windows.Forms.NumericUpDown uxBoard1Value1;
        private System.Windows.Forms.TextBox uxAreDoubleEqual;
        private System.Windows.Forms.Label uxDoubleEqualsLabel;
        private System.Windows.Forms.TextBox uxAreEqual;
        private System.Windows.Forms.Label uxEqualsLabel;
        private System.Windows.Forms.Button uxCompare;
        private System.Windows.Forms.Label uxLimit2Label;
        private System.Windows.Forms.Label uxValues2Label;
        private System.Windows.Forms.Label uxBoard2Label;
        private System.Windows.Forms.Label uxLimitsLabel1;
        private System.Windows.Forms.Label uxValueLabel1;
        private System.Windows.Forms.Label uxBoard1Label;
    }
}

